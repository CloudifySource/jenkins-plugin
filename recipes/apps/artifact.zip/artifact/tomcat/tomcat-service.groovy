/*******************************************************************************
 * Copyright (c) 2012 GigaSpaces Technologies Ltd. All rights reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/
import static JmxMonitors.*
//import com.groovyclouds.aws.S3Driver
import org.apache.commons.codec.binary.*

import com.amazonaws.auth.AWSCredentials
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider
import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.GetObjectRequest
import com.amazonaws.services.s3.model.S3Object
import com.amazonaws.regions.Region
import com.amazonaws.regions.Regions
import java.util.concurrent.TimeUnit

service {
	extend "../../../services/tomcat"
	elastic false
	numInstances 1
	minAllowedInstances 1
	maxAllowedInstances 1

	def portIncrement =  context.isLocalCloud() ? context.getInstanceId()-1 : 0

	def currJmxPort = jmxPort + portIncrement
	def currHttpPort = port + portIncrement
	def currAjpPort = ajpPort + portIncrement

	customCommands ([
		"downloadFromS3" : {accessKey,secretKey,bucketName,fileName ->

			AWSCredentials c=new BasicAWSCredentials(accessKey, secretKey)

			AmazonS3 s3 = new AmazonS3Client(c);

			//Region usWest2 = Region.getRegion(Regions.AP_NORTHEAST_1)

			//s3.setRegion(usWest2);

			S3Object object = s3.getObject(new GetObjectRequest(bucketName, fileName));

			def input=object.getObjectContent()

			def fout= new FileOutputStream("${context.serviceDirectory}/${fileName}")

			byte[] buffer = new byte[8192];
			int bytesRead;

			while ((bytesRead = input.read(buffer)) != -1) {
				fout.write(buffer, 0, bytesRead);
			}

			context.attributes.thisService["warUrl"] = "${fileName}"
			
			def service = context.waitForService(context.serviceName, 60, TimeUnit.SECONDS)
			def currentInstance = service.getInstances().find{ it.instanceId == context.instanceId }
			currentInstance.invoke("updateWarFile")

			new File("${context.serviceDirectory}/${fileName}").delete()

			return true;
		}
	])
	lifecycle {

		details {
			def currPublicIP

			if (  context.isLocalCloud()  ) {
				currPublicIP =InetAddress.localHost.hostAddress
			}
			else {
				currPublicIP = System.getenv()["CLOUDIFY_AGENT_ENV_PUBLIC_IP"]
			}
			def tomcatURL = "http://${currPublicIP}:${currHttpPort}"

			def applicationURL = "${tomcatURL}/${ctxPath}"
			println "tomcat-service.groovy: applicationURL is ${applicationURL}"

			return [
				"Application URL":"<a href=\"${applicationURL}\" target=\"_blank\">${applicationURL}</a>"
			]
		}

		monitors {

			def metricNamesToMBeansNames = [
				"Current Http Threads Busy": [
					"Catalina:type=ThreadPool,name=\"http-bio-${currHttpPort}\"",
					"currentThreadsBusy"
				],
				"Current Http Thread Count": [
					"Catalina:type=ThreadPool,name=\"http-bio-${currHttpPort}\"",
					"currentThreadCount"
				],
				"Backlog": [
					"Catalina:type=ProtocolHandler,port=${currHttpPort}",
					"backlog"
				],
				"Total Requests Count": [
					"Catalina:type=GlobalRequestProcessor,name=\"http-bio-${currHttpPort}\"",
					"requestCount"
				],
				"Active Sessions": [
					"Catalina:type=Manager,context=/${ctxPath},host=localhost",
					"activeSessions"
				],
			]

			return getJmxMetrics("127.0.0.1",currJmxPort,metricNamesToMBeansNames)
		}
	}
}